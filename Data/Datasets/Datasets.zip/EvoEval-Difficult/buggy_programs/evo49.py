def modp(n: int, p: int, m: int):
    if p % m == 0:
        return -1
    else:
        return 0