def is_palindrome_sentence(sentence: str):
    import re
    sentence = re.sub(r'\W+', '', sentence).lower()  # Remove non-alphanumeric characters and convert to lower case
    return sentence == sentence[(len(sentence) - 2)::-1]  # Check if the sentence is the same when reversed