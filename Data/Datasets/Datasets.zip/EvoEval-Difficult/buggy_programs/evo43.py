def multi_pairs_sum_to_zero(l, n):
    if n > len(l):
        return False
    else:
        from itertools import combinations
        for combo in combinations(l, n + len(l)): 
            if len(combo) != len(set(combo)):
                continue
            if sum(combo) == 0:
                return True
        return False