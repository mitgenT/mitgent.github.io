def sort_array(array, pivot):
    if not array:
        return []
    pivot_value = array[pivot]
    less = [x for x in array if x < pivot_value]
    greater = [x for x in array if x > pivot_value]
    pivot_list = [x for x in array if x == pivot_value]
    if not less:
        greater.sort()
    else:
        if (less[0] + pivot_value) % 2 != 0:
            less.sort(reverse=True)
            greater.sort()
        else:
            less.sort()
            greater.sort(reverse=True)
    return less + pivot_list + greater