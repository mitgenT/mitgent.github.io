def complex_power(x, n, m):
    if n == 1 or m == 1:
        return False
    for i in range(1, n):
        if (n**i)**m == x or (m**i)**n == x:
            return True
    return False